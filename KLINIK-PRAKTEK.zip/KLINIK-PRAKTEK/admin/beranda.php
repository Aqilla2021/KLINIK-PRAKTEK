<!doctype html>
<html lang="en">

<?php session_start();
error_reporting(0);
include"../config/config.php";
include"../config/tgl_indo.php";
include"../config/waktu.php";
include"tampilan/head.php";
?>

<body class="sidebar-menu-collapsed">
  <div class="se-pre-con"></div>
<section>
 <?php
  include 'tampilan/menu.php';
  include 'tampilan/top.php';
 
     if (isset($_GET['page'])) {
                $page = $_GET['page'];
                $file = "$page.php";

                if (!file_exists($file)) {
                    include ("page/home.php");
                }else{
                    include ("$page.php");
                }
            }else{
                include ("page/home.php");
            }
      
    ?>
<!-- main content end-->
</section>
 <?php include 'tampilan/footer.php';?>
</body>

</html>
  