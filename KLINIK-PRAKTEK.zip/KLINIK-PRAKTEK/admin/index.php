
<?php session_start();
include"../config/config.php";
include"../config/tgl_indo.php";
include"../config/waktu.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="starter/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="starter/css/style.css">
	<link rel="stylesheet" type="text/css" href="starter/css/bootstrap-theme.css">
	<script  src="starter/js/jquery.js"></script>
	<script  src="starter/js/bootstrap.min.js"></script>
 <script type="text/javascript">
    $( document ).ready(function() {
     $( "#target" ).click();
   });
 </script>

</head>
<body>
  

 <input  type="hidden" class="btn btn-primary" id="target" data-toggle="modal" data-target="#exampleModal" data-whatever="@getbootstrap">

 <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" style="background-color: green;">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Silahkan Login</h4>
      </div>
      <div class="modal-body">
        <form action="" method="POST">
          <div class="form-group">
            <label for="recipient-name" class="control-label">username</label>
            <input type="text" class="form-control"  placeholder="Username" name="user" autofocus autocomplete="off">
          </div>
          <div class="form-group">
            <label for="message-text" class="control-label">Password</label>
            <input type="password" class="form-control"  placeholder="Password" name="pass" autocomplete="off">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-warning" name="simpan">Login</button>
        </div>
      </form>
    </div>
  </div>
</div>
</body>
</html>
<?php 
if (isset($_POST['simpan'])) {
  

$username = $_POST['user'];
  $password = $_POST['pass'];

   $log =  $koneksi->query( "SELECT * FROM admin WHERE username='$username' AND password='$password'");
    $data = mysqli_fetch_array($log); 
if(mysqli_num_rows($log) == 1){
    session_start();
    $_SESSION['id'] = $data['id_admin'];
    $_SESSION['nama'] = $data['nama'];
    $_SESSION['foto'] = $data['foto'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['password'] = $data['password'];
    echo "
  <script>
  alert('LOGIN BERHASIL!!!');
  window.location = 'beranda.php';
  </script>
  ";
  }else{
  echo "
  <script>
  alert('GAGAL LOGIN');
  window.location = 'index.php';
  </script>
  ";
  }
}
?><?php   //error_reporting(0);
     ?>