
<div class="main-content">

  <!-- content -->
  <div class="container-fluid content-top-gap">

     <div class="data-tables">
      <div class="row">


<div class="container"><br>
  <h2 style=" width: 100%; border-bottom: 4px solid red"><b>Data admin</b></h2>
  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">Nama</th>
        <th scope="col">Username</th>
        <th scope="col">Foto</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      $result = $koneksi->query( "SELECT * FROM admin order by id_admin asc");
      $no =1;
      while ($row = mysqli_fetch_assoc($result)) {
        ?>
        <tr>

          <th scope="row"><?php echo $no; ?></th>
          <td><?= $row['nama'];  ?></td>
          <td><?= $row['username'];  ?></td>
          <td><img src="../images/admin/<?= $row['foto'];  ?>" width="100px"></td>
          <td>
            <a href="" data-toggle="modal" data-target="#editModal<?php echo $row['id_admin']; ?>" class="btn btn-warning"><i class="fa fa-check-square-o"></i> </a> 
             <div class="modal fade" id="editModal<?php echo $row['id_admin']; ?>" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel1" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel1">Edit Admin</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                         <form action="" method="POST" enctype="multipart/form-data">
    <div class="row">
      <div class="col">
       <label for="exampleInputEmail1">Nama</label>
          
        
      <input type="text" class="form-control"  name="nama" value="<?= $row['nama']; ?>">

          <input type="hidden" class="form-control"   name="id" value="<?= $row['id_admin']; ?>">
       
        <label for="exampleInputEmail1">username</label>
          <input type="text" class="form-control"  name="username" value="<?= $row['username']; ?>">
        
         <label for="exampleInputEmail1">Password</label>
          <input type="password" class="form-control"  name="password" value="<?= $row['password']; ?>">
        
       
           
         <label for="exampleInputEmail1">Foto</label>
          <input type="file" class="form-control"  name="foto" >
        
          
      </div>
    </div>

 
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                          <button type="submit" name="edit"class="btn btn-success">Simpan</button>
                        </div>
                         </form>
                      </div>
                    </div>
                  </div>
            <a href="?page=page/admin/hapus&kode=<?php echo $row['id_admin'];?>" class="btn btn-danger" onclick="return confirm('Yakin Ingin Menghapus Data ?')"><i class="fa fa-trash"></i> </a></td>
        </tr>
        <?php 
        $no++;
      }
      ?>
    </tbody>
  </table>
   <a href="" data-toggle="modal" data-target="#editModal" class="btn btn-warning"><i class="fa fa-plus-square-o"></i>Tambah Admin </a> 
             <div class="modal fade" id="editModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel1" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel1">Tambah Admin</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                         <form action="" method="POST" enctype="multipart/form-data">
    <div class="row">
      <div class="col">
       <label for="exampleInputEmail1">Nama</label>
          
        
      <input type="text" class="form-control"  name="nama" required="">

          <input type="hidden" class="form-control"   name="id" >
       
        <label for="exampleInputEmail1">username</label>
          <input type="text" class="form-control"  name="username" required="">
        
         <label for="exampleInputEmail1">Password</label>
          <input type="password" class="form-control"  name="password" required="">
        
       
            
         <label for="exampleInputEmail1">Foto</label>
          <input type="file" class="form-control"  name="foto" required="">
        
          
      </div>
    </div>

 
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                          <button type="submit" name="simpan"class="btn btn-success">Simpan</button>
                        </div>
                         </form>
                      </div>
                    </div>
                  </div>
</div>
</div>
</div>
</div>
<!-- Button trigger modal -->

<?php if(isset($_POST['simpan'])){
     $file_name = $_FILES['foto']['name'];
        $tmp_name = $_FILES['foto']['tmp_name'];
        $nama=addslashes($_POST['nama']);
        $username=addslashes($_POST['username']);
        $password=addslashes($_POST['password']);

        $query_simpan =$koneksi->query( "INSERT INTO admin SET 
        nama='$nama',
        username='$username',
        password='$password',
        foto='$file_name'
        ");
        move_uploaded_file($tmp_name, "../images/admin/".$file_name);

    if ($query_simpan) {
      echo"<script>alert('Data Admin Berhasil di tambah !!!'); window.location = '?page=page/admin/index&id=Data Admin'</script>";
      }else{
      echo"<script>alert('Data Admin Gagal di Simpan !!!'); window.location = '?page=page/admin/tambah'</script>";
    }
}elseif (isset($_POST['edit'])) {
   
  $foto   = $_FILES['foto']['name'];
  $pp = $_POST['password'];
  if (empty($foto)){
    $koneksi->query("UPDATE admin SET 
                    nama     = '$_POST[nama]',
                    username = '$_POST[username]',
                    password = '$_POST[username]'
                    WHERE id_admin = '$_POST[id]'");
}else{


    $hapus= $koneksi->query("select * from admin where id='$_POST[id]'");
    $tanggal_foto=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_foto['foto'];
    $hapus_foto="../images/admin/$lokasi";
    unlink($hapus_foto);
    move_uploaded_file($_FILES['foto']['tmp_name'],'../images/admin/'.$foto);
    $koneksi->query("UPDATE admin SET nama     = '$_POST[nama]',
                      nama     = '$_POST[nama]',
                    username = '$_POST[username]',
                    password = '$_POST[username]',
                    foto  = '$foto'
                    WHERE id_admin= '$_POST[id]'");
  }
echo"<script>alert('Data Berhasil di Ubah!!!'); window.location = '?page=page/admin/index&id=Data Admin'</script>";
 
}

 ?>
