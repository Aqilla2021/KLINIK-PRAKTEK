
<?php  $kode = $_GET['kode'];
  $result =$koneksi->query("DELETE FROM admin WHERE id_admin = '$kode'");

  if($result){
    echo "
    <script>
    alert('DATA BERHASIL DIHAPUS');
    window.location = '?page=page/admin/index';
    </script>
    ";
  
}?>