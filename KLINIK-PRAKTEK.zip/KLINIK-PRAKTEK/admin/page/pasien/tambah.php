<div class="main-content">

  <!-- content -->
  <div class="container-fluid content-top-gap">

     <div class="data-tables">
      <div class="row">



<?php 
 $kode = $koneksi->query( "SELECT norekammedik from pasien order by norekammedik desc");
  $data = mysqli_fetch_assoc($kode);
  $num = substr($data['norekammedik'], 2, 4);
  $add = (int) $num + 1;
  if(strlen($add) == 1){
    $format = "HB000".$add;
  }else if(strlen($add) == 2){
    $format = "HB00".$add;
  }
  else if(strlen($add) == 3){
    $format = "HB0".$add;
  }else{
    $format = "HB".$add;
  }



?>


<div class="container">
  <br>
  <h2 style=" width: 100%; border-bottom: 4px solid red"><b>Tambah Bahan</b></h2><p><br></p>

  <form action="" method="POST" enctype="multipart/form-data">
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Kode Bahan</label>
          <input type="text" class="form-control" id="exampleInputEmail1" disabled value="<?php echo $format; ?>">

          <input type="hidden" class="form-control" id="exampleInputEmail1"  name="kd_material" value="<?php echo $format; ?>">
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Nama Bahan</label>
          <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Nama Bahan" name="nama">
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Stok</label>
          <input type="number" class="form-control" id="exampleInputEmail1"  name="stok" placeholder="contoh 2 atau 0.4" min="1">
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Satuan</label>
          <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Contoh : Kg atau gram" name="satuan">
            <p class="help-block">Hanya Masukkan Satuan saja : Kg atau gram</p>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Harga</label>
          <input type="number" class="form-control" id="exampleInputEmail1"  name="harga" placeholder="Contoh : 1000" min="1">
          <p class="help-block">Harga termasuk harga per kg atau per  gram</p>
        </div>
      </div>
    </div>
    <button type="submit"  name="simpan"class="btn btn-success" ><i class="glyphicon glyphicon-plus-sign"></i> Tambah</button>
    <a href="?page=page/bahan/index" class="btn btn-danger">Cancel</a>
  </form>
</div>

<br>

</div>
</form>

</div>


</div></div>
  </div>
  <!-- //content -->
</div>
<?php if(isset($_POST['simpan'])){
  $kode = $_POST['kd_material'];
  $nama = $_POST['nama'];
  $stok = $_POST['stok'];
  $satuan = $_POST['satuan'];
  $harga = $_POST['harga'];
  $tanggal = date("y-m-d");

  $result = $koneksi->query( "INSERT INTO inventory VALUES('$kode','$nama','$stok', '$satuan', '$harga', '$tanggal')");

  if($result){
    echo "
      <script>
        alert('DATA BERHASIL DITAMBAHKAN');
        window.location = '?page=page/bahan/index';
      </script>
    ";
  }
}

 ?>