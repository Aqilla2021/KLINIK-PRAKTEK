
<?php  $kode = $_GET['kode'];
  $result =$koneksi->query("DELETE FROM pasien WHERE id_pasien = '$kode'");

  if($result){
    echo "
    <script>
    alert('Data Berhasil Dihapus');
    window.location = '?page=page/pasien/index';
    </script>
    ";
  
}?>