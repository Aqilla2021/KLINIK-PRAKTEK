
<div class="main-content">

  <!-- content -->
  <div class="container-fluid content-top-gap">

     <div class="data-tables">
      <div class="row">


<div class="container"><br>
  <h2 style=" width: 100%; border-bottom: 4px solid red"><b>Data Pasien</b></h2>
  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">Nama</th>
        <th scope="col">No Hp</th>
        <th scope="col">Alamat</th>
        <th scope="col">Status</th>
      </tr>
    </thead>
    <tbody>
      <?php 
         $kode = $koneksi->query( "SELECT norekammedik from pasien order by norekammedik desc");
  $data = mysqli_fetch_assoc($kode);
  $num = substr($data['norekammedik'], 2, 4);
  $add = (int) $num + 1;
  if(strlen($add) == 1){
    $format = "HB000".$add;
  }else if(strlen($add) == 2){
    $format = "HB00".$add;
  }
  else if(strlen($add) == 3){
    $format = "HB0".$add;
  }else{
    $format = "HB".$add;
  }

      $result = $koneksi->query( "SELECT * FROM pasien order by id_pasien asc");
      $no =1;
      while ($row = mysqli_fetch_assoc($result)) {
        $paa=mysqli_num_rows($koneksi->query("select * from rekammedik where  nik='$row[nik]'"));
        if($paa > 2){
          $status='Lama';
        }else{
          $status='Baru';
        }
        ?>
        <tr>

          <th scope="row"><?php echo $no; ?></th>
          <td><?= $row['nama'];  ?></td>
          <td><?= $row['no_hp'];?></td>
          <td><?= $row['alamat'];?></td>
          <td><?= $status;?></td>
          
        </tr>
        <?php 
        $no++;
      }
      ?>
    </tbody>
  </table>
 
   <div class="modal fade" id="tambahModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel1" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel1">Tambah Pasien</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                         <form action="" method="POST" enctype="multipart/form-data">
    <div class="row">
      <div class="col">
       <label for="exampleInputEmail1">NIK</label>
      <input type="text" class="form-control"  name="nik" required="">
      <input type="hidden" class="form-control"  name="norekammedik" value="<?= $format;?>">
       <label for="exampleInputEmail1">Nama</label>
      <input type="text" class="form-control"  name="nama"  required="">

          <input type="hidden" class="form-control"   name="id" >
       
        
       <label for="exampleInputEmail1"> No Hp</label>
          <input type="text" class="form-control"  name="no_hp" required="">
        
       <label for="exampleInputEmail1"> Alamat</label>
       <textarea class="form-control" name="alamat" required=""></textarea>
        
        
          
      </div>
    </div>

 
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                          <button type="submit" name="simpan"class="btn btn-success">Simpan</button>
                        </div>
                         </form>
                      </div>
                    </div>
                  </div>
</div>
</div>
</div>
</div>
<!-- Button trigger modal -->

<?php if(isset($_POST['simpan'])){
        $nama=addslashes($_POST['nama']);
        $no_hp=addslashes($_POST['no_hp']);
        $alamat=addslashes($_POST['alamat']);
        $norekammedik=addslashes($_POST['norekammedik']);
 $result = $koneksi->query( "SELECT * FROM pasien order by id_pasien asc");
     $row = mysqli_fetch_assoc($result);
     if($row['nik']==$_POST['nik']){
      echo"<script>alert('Data pasien sudah ada  !!!'); window.location = '?page=page/pasien/index'</script>";
     }else{
      $query_simpan =$koneksi->query( "INSERT INTO pasien SET 
        nama='$nama',
        norekammedik='$norekammedik',
        nik='$_POST[nik]',
        no_hp='$no_hp',
        alamat='$alamat'
        ");

    if ($query_simpan) {
      echo"<script>alert('Data pasien Berhasil di tambah !!!'); window.location = '?page=page/pasien/index&id=Data pasien'</script>";
      }else{
      echo"<script>alert('Data pasien Gagal di Simpan !!!'); window.location = '?page=page/pasien/index'</script>";
    }
     }
        
}elseif (isset($_POST['edit'])) {
   $nama=addslashes($_POST['nama']);
        $no_hp=addslashes($_POST['no_hp']);
        $alamat=addslashes($_POST['alamat']);

        $query_simpan =$koneksi->query( "UPDATE pasien SET 
        nama='$nama',
        nik='$_POST[nik]',
        no_hp='$no_hp',
        alamat='$alamat'
                    WHERE id_pasien = '$_POST[id]'");

echo"<script>alert('Data Berhasil di Edit!!!'); window.location = '?page=page/pasien/index'</script>";
 
}

 ?>
