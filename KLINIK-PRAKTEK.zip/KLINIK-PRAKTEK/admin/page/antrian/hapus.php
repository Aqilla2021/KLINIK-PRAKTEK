
<?php  
$kode = $_GET['kode'];
  $result =$koneksi->query("DELETE FROM antrian WHERE id_antrian = '$kode'");

  if($result){
    echo "
    <script>
    alert('DATA BERHASIL DIHAPUS');
    window.location = '?page=page/antrian/all';
    </script>
    ";
  }
?>