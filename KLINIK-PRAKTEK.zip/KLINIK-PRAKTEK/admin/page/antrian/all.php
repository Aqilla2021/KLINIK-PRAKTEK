
<div class="main-content">

  <!-- content -->
  <div class="container-fluid content-top-gap">

     <div class="data-tables">
      <div class="row">


<div class="container"><br>
  <h2 style=" width: 100%; border-bottom: 4px solid red"><b>Data Semua Antrian</b><br>
  <a href="?page=page/antrian/index" class="btn btn-success">Lihat Antrian Hari Ini </a> </h2>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>No</th>
        <th scope="col">No Antrian</th>
        <th scope="col">Tanggal</th>
        <th scope="col">Nama Pasien</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      

      $resulta = $koneksi->query( "SELECT * FROM antrian   order by tgl desc");
     $no=0;
      while ($row = mysqli_fetch_assoc($resulta)) {
        $no++;
        $resultap = $koneksi->query( "SELECT * FROM pasien  where nik='$row[nik]'");
        $pasien = mysqli_fetch_assoc($resultap);
        ?>
        <tr>

          <th scope="row"><?= $no; ?></th>
          <th scope="row"><?= $row['no']; ?></th>
          <th scope="row"><?= tgl_indonesia($row['tgl']); ?></th>
          <td><?= $pasien['nama'];  ?></td>
          <td>
                  <a href="" data-toggle="modal"
                    data-target="#exampleModalLabel1<?php echo $row['id_antrian']; ?>" class="btn btn-warning"><i class="fa fa-check-square-o"></i> </a> 
<div class="modal fade" id="exampleModalLabel1<?php echo $row['id_antrian']; ?>" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Edit Antrian</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                         <form action="" method="POST" enctype="multipart/form-data">
    <div class="row">
      
      <div class="col">
       
           <label for="exampleInputEmail1">No Antrian</label>
          <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Nama Satuan" name="no" value="<?= $row['no'];?>" >
        
            
       <label for="exampleInputEmail1">Nama</label>
      <input type="text" class="form-control"  name="nama"  value="<?= $pasien['nama'];?>">
      <input type="hidden" class="form-control"  name="idp"  value="<?= $pasien['id_pasien'];?>">
      <input type="hidden" class="form-control"  name="id"  value="<?= $row['id_antrian'];?>">

       
       <label for="exampleInputEmail1"> No Hp</label>
          <input type="text" class="form-control"  name="no_hp"  value="<?= $pasien['no_hp'];?>">
        
        
      </div>
    </div>

 
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                          <button type="submit" name="edit" class="btn btn-success">Edit</button>
                        </div>
                         </form>
                      </div>
                    </div>
                  </div>
                    <a href="?page=page/antrian/hapus&kode=<?php echo $row['id_antrian'];?>" class="btn btn-danger" onclick="return confirm('Yakin Ingin Menghapus Data ?')"><i class="fa fa-trash"></i> </a></td>
        </tr>
        <?php 
      }
      ?>
    </tbody>
  </table> <a href="" data-toggle="modal" data-target="#editModal" class="btn btn-warning"><i class="fa fa-plus-square-o"></i>Tambah Antrian </a> 
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Buat Antrian</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          Note ** silahkan inputkan Tanggal dan NIK saja jika sudah pernah melakukan kunjungan Berobat
                         <form action="" method="POST" enctype="multipart/form-data">
    <div class="row">
      
      <div class="col">
       
          <label for="exampleInputEmail1">Tanggal</label>
          <input type="date" class="form-control" id="exampleInputEmail1"  name="tgl" required="" >
          
           <label for="exampleInputEmail1">NIK</label>
      <input type="text" class="form-control"  name="nik" required="">
       <label for="exampleInputEmail1">Nama</label>
      <input type="text" class="form-control"  name="nama" >

          <input type="hidden" class="form-control"   name="id">
       
       <label for="exampleInputEmail1"> No Hp</label>
          <input type="text" class="form-control"  name="no_hp"  >
        
       <label for="exampleInputEmail1"> Alamat</label>
       <textarea class="form-control" name="alamat" ></textarea>
        
        
       
        
      </div>
    </div>

 
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                          <button type="submit" name="antri"class="btn btn-success">Buat Antrian</button>
                        </div>
                         </form>
                      </div>
                    </div>
                  </div>
</div>
</div>
</div>
</div>
<?php if(isset($_POST['simpan'])){
  $kode = $_POST['nama_satuan'];

  $result = $koneksi->query( "INSERT INTO satuan SET nama_satuan='$kode' ");

  if($result){
    echo "
      <script>
        alert('DATA BERHASIL DITAMBAHKAN');
        window.location = '?page=page/satuan/index';
      </script>
    ";
  }
}elseif(isset($_POST['edit'])){
  $noan=addslashes($_POST['no']);
   $nama=addslashes($_POST['nama']);
   $no_hp=addslashes($_POST['no_hp']);
 
     
        $result = $koneksi->query( "UPDATE antrian SET 
          no='$noan' where id_antrian='$_POST[id]' ");
        $query_simpan =$koneksi->query( "UPDATE pasien SET 
        nama='$nama',
        no_hp='$no_hp' where id_pasien='$_POST[idp]'
        ");
         if($result){
    echo "
      <script>
        alert('DATA BERHASIL DI EDIT');
        window.location = '?page=page/antrian/all';
      </script>
    ";
  }
      
  

 
}elseif(isset($_POST['panggil'])){
  $kode = $_POST['id_pasien'];

  if($_POST['status']=='Datang'){
  $result = $koneksi->query( "UPDATE antrian SET id_pasien='$kode' where id_antrian='$_POST[id]' and status='$_POST[status]' ");

    echo "
      <script>
        alert('DATA BERHASIL DI EDIT');
        window.location = '?page=page/rekammedik/index&id=$_POST[id_pasien]';
      </script>
    ";
  }else{
        echo "
      <script>
        alert('Pasien Tidak datang');
        window.location = '?page=page/antrian/index';
      </script>
    ";
  }
  }elseif (isset($_POST['antri'])) {


   $alamat=addslashes($_POST['alamat']);
   $nama=addslashes($_POST['nama']);
   $nik=addslashes($_POST['nik']);
   $no_hp=addslashes($_POST['no_hp']);
   $tgl=addslashes($_POST['tgl']);
   $result = $koneksi->query( "SELECT * FROM antrian  where tgl='$tgl' and status='Aktif' order by no desc");
      $cob=mysqli_fetch_array($result);

      $antr=$cob['no'];
      $tl=$cob['no'];
      $p=mysqli_num_rows($koneksi->query("select * from antrian where tgl='$tgl' and status='Aktif' "));

             if($p == 0){ $antr='1';}else{ $antr=$tl+1;}
if($antr == 15){
  echo"<script>alert('Pendfataran sudah penuh silahkan pilih tanggal lain!!!'); window.location = '?page=page/antrian/all'</script>";
}else{
   $pa=mysqli_num_rows($koneksi->query("select * from antrian where tgl='$tgl' and nik='$nik' "));
if($pa==1){echo"<script>alert('PASIEN SUDAH MENGAMBIL ANTRIAN!!!'); window.location = '?page=page/antrian/all'</script>";}else{
  $pas=mysqli_num_rows($koneksi->query("select * from pasien where nik='$nik'  "));
  if($pas ==1){}else{
    $query_simpan =$koneksi->query( "INSERT INTO pasien SET 
        nama='$nama',
        nik='$nik',
        alamat='$alamat',
        no_hp='$no_hp'
        ");
  }
        $query_simpan =$koneksi->query( "INSERT INTO antrian SET 
        no='$antr',
        nik='$nik',
        jam='$jam_sekarang',
        status='Aktif',
        tgl='$tgl'
        ");

echo"<script>alert('DATA BERHASIL DISIMPAN!!!'); window.location = '?page=page/antrian/all'</script>";
 }
}
}


 ?>