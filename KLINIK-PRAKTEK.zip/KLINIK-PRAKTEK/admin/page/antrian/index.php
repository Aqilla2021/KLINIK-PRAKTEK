
<div class="main-content">

  <!-- content -->
  <div class="container-fluid content-top-gap">

     <div class="data-tables">
      <div class="row">


<div class="container"><br>
  <h2 style=" width: 100%; border-bottom: 4px solid red"><b>Data Antrian Hari Ini</b><br><a href="?page=page/antrian/all" class="btn btn-success">Lihat Semua Antrian </a> </h2>
  
  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">No Antrian</th>
        <th scope="col">Nama Pasien</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      

      $resulta = $koneksi->query( "SELECT * FROM antrian  where tgl='$tgl_sekarang'  order by no asc");
     
      while ($row = mysqli_fetch_assoc($resulta)) {
        $resultap = $koneksi->query( "SELECT * FROM pasien  where nik='$row[nik]'");
        $pasien = mysqli_fetch_assoc($resultap);
        ?>
        <tr>

          <th scope="row"><?= $row['no']; ?></th>
          <td><?= $pasien['nama'];  ?></td>
          <td><?php if($row['ket']=='Lanjut Rekam Medik'){?><a href="?page=page/rekammedik/tambah&id=<?= $row['nik'];?>&id_antrian=<?= $row['id_antrian'];?>" class="btn btn-warning">Buat Rekam Medik</a><?php }else{ echo $row['ket'];}?><?php if($row['status'] =='Aktif' or $row['status'] =='Ganti Tanggal'){?><a href="" data-toggle="modal"
                    data-target="#exampleModalLabel<?php echo $row['id_antrian']; ?>" class="btn btn-warning"><i class="fa fa-sound-square-o"></i> Panggil</a> <?php }else{}?>
<div class="modal fade" id="exampleModalLabel<?php echo $row['id_antrian']; ?>" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Panggil Pasien</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                         <form action="" method="POST" enctype="multipart/form-data">
    <div class="row">
      
      <div class="col">
       
           <label for="exampleInputEmail1">No Antrian</label>
          <input type="text" class="form-control"  placeholder="Nama Satuan" name="no" value="<?= $row['no'];?>" readonly/>
        
           <label for="exampleInputEmail1">Nama Pasien</label>
           <input type="text" class="form-control"   name="" value="<?= $pasien['nama'];?>" readonly/>
          
           
          <input type="hidden" class="form-control" placeholder="Nama Satuan" name="id" value="<?= $row['id_antrian'];?>" readonly/>
          <input type="hidden" class="form-control"  placeholder="Nama Satuan" name="nik" value="<?= $pasien['nik'];?>" >
          <label for="exampleInputEmail1">Status</label>
          <select name="statuss" class="form-control input-style" required="">
            <option>Pilih</option>
            <option value="Datang"> Datang</option>
            <option value="Tidak Datang"> Tidak Datang</option>
          </select>
          
      </div>
    </div>

 
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                          <button type="submit" name="panggil"class="btn btn-success">Simpan</button>
                        </div>
                         </form>
                      </div>
                    </div>
                  </div>
                </td>
        </tr>
        <?php 
      }
      ?>
    </tbody>
  </table>
</div>
</div>
</div>
</div>
<?php 
if(isset($_POST['panggil'])){
  

  if($_POST['statuss']=='Datang'){
  $resultt = $koneksi->query( "UPDATE antrian SET status='$_POST[statuss]', ket='Lanjut Rekam Medik' where id_antrian='$_POST[id]' ");

    echo "
      <script>
        alert('DATA BERHASIL DI SIMPAN');
        window.location = '?page=page/rekammedik/tambah&id=$_POST[nik]&id_antrian=$_POST[id]';
      </script>
    ";
  }else{
     $resultt = $koneksi->query( "UPDATE antrian SET status='$_POST[statuss]' where id_antrian='$_POST[id]' ");
        echo "
      <script>
        alert('Pasien Tidak datang');
        window.location = '?page=page/antrian/index';
      </script>
    ";
  }
  }


 ?>