<script src="tampilan/jquery.min.js" type="text/javascript"></script>
 <div class="main-content">

<?php 

$result = $koneksi->query( "SELECT * FROM kontak WHERE id_kontak = '1'");
$row= mysqli_fetch_assoc($result);
if (isset($_POST['update'])) {
   
  $foto   = $_FILES['logo']['name'];
  if (empty($foto)){
    $koneksi->query("UPDATE kontak SET 
                    judul     = '$_POST[judul]',
                    tlp = '$_POST[tlp]',
                    email = '$_POST[email]',
                    maps = '$_POST[maps]',  
                    alamat = '$_POST[alamat]' 
                    WHERE id_kontak = '1'");
}else{


    $hapus= $koneksi->query("select * from kontak where id_kontak='1'");
    $tanggal_foto=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_foto['logo'];
    $hapus_foto="../images/$lokasi";
    unlink($hapus_foto);
    move_uploaded_file($_FILES['logo']['tmp_name'],'../images/'.$foto);
    $koneksi->query("UPDATE kontak SET judul     = '$_POST[judul]',
                    tlp = '$_POST[tlp]',
                    email = '$_POST[email]',
                    maps = '$_POST[maps]',  
                    alamat = '$_POST[alamat]',
                    logo  = '$foto'
                    WHERE id_kontak= '1'");
  }
echo"<script>alert('Data Berhasil di Update!!!'); window.location = '?page=page/kontak/index'</script>";
 
}
?>
  <!-- content -->
  <div class="container-fluid content-top-gap">

     <div class="data-tables">
      <div class="row">
       <div class="container">
    <div class="account">
       <h2 style=" width: 100%; border-bottom: 4px solid red"><b>Kontak Kami</b></h2><p><br></p>
        
<div id="angka">
            
               <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                
           <div id="input">
      <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Nama Web</label>
          <input type="text" class="form-control input-style"  name="judul" value="<?php echo $row['judul']; ?>">

        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Alamat</label>
          <input type="text" class="form-control input-style" name="alamat" value="<?= $row['alamat'];?>">
         </div>
      </div>
    </div>
     <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Telpon </label>
          <input type="text" class="form-control input-style" id="exampleInputEmail1" name="tlp" value="<?php echo $row['tlp']; ?>">

        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Email</label>
          <input type="email" class="form-control input-style" name="email" value="<?= $row['email'];?>">
         </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Logo </label><br>
          <img src="../images/<?= $row['logo'];?>" style="width: 200px; height:200px;">
          <input type="file" class="form-control input-style" id="exampleInputEmail1" name="logo" >

        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="exampleInputEmail1">Maps</label><br>
          <iframe src="<?= $row['maps'];?>" style="width: 400px; height:400px;"></iframe>
          <textarea class="form-control input-style" name="maps" type="text"><?= $row['maps'];?></textarea>
         </div>
      </div>
    </div>
    
    
                        
                                    <div class="col-sm-8">
                                  
        <button type="submit" name="update" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-plus" aria-hidden="true"></i>Update</button>
                                    </div>
                                    
                                
                         </form>
    </div>
        </div>
        </div>
  </div>
  </div>
        </div>
        </div>
  </div>
  