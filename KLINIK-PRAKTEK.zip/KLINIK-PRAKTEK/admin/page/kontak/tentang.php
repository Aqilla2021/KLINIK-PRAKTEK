<script src="tampilan/jquery.min.js" type="text/javascript"></script>
 <div class="main-content">

<?php 

$result = $koneksi->query( "SELECT * FROM kontak WHERE id_kontak = '1'");
$row= mysqli_fetch_assoc($result);
if (isset($_POST['update'])) {
   
 
    $koneksi->query("UPDATE kontak SET 
                    tentangkami     = '$_POST[tentangkami]'
                    WHERE id_kontak = '1'");

echo"<script>alert('Data Berhasil di Update!!!'); window.location = '?page=page/kontak/tentang'</script>";
 
}
?>
  <!-- content -->
  <div class="container-fluid content-top-gap">

     <div class="data-tables">
      <div class="row">
       <div class="container">
    <div class="account">
       <h2 style=" width: 100%; border-bottom: 4px solid red"><b>Tentang Kami</b></h2><p><br></p>
        
<div id="angka">
            
               <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                
           <div id="input">
      <div class="row">
     <textarea  name="tentangkami"style="width: 100%; height:400px"><?= $row['tentangkami'];?></textarea>
      
    </div>
     
    
    
    
                        
                                    <div class="col-sm-8">
                                  
        <button type="submit" name="update" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-check-square-o" aria-hidden="true"></i>Update</button>
                                    </div>
                                    
                                
                         </form>
    </div>
        </div>
        </div>
  </div>
  </div>
        </div>
        </div>
  </div>
  