<?php
	require 'config/config.php';
 
	if(ISSET($_POST['filter'])){
		$month = $_POST['month'];
		$year = $_POST['year'];
		$months = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
 
 
?>
		<?php
			echo "<h3>".$months[$month - 1]." ".$year."</h3>";
		?>
		<ul class="nav nav-tabs">
			<li class="active"><a data-toggle="tab" href="#week1">Week 1</a></li>
			<li><a data-toggle="tab" href="#week2">Week 2</a></li>
			<li><a data-toggle="tab" href="#week3">Week 3</a></li>
			<li><a data-toggle="tab" href="#week4">Week 4</a></li>
		</ul>
		<div class="tab-content">
			<div id="week1" class="tab-pane fade in active" style="padding:10px;">
				<table class="table table-bordered">
					<thead class="alert-success">
						<tr>
							<th>Item Name</th>
							<th>Brand Name</th>
						</tr>
					</thead>
					<tbody style="background-color:#fff;">
						<?php
							$data = [];
							$week = [];
							$i = 0;
							$query = $koneksi->query( "SELECT WEEK(tgl) AS 'week', nik, no FROM antrian WHERE YEAR(tgl) = '$year' && MONTH(tgl) = '$month' ORDER BY 'week' ASC") or die(mysqli_error());
							while($fetch = mysqli_fetch_assoc($query)){
								$week[$i] = $fetch['week'];
								$data[$i] = array('week' => $fetch['week'],'nik' => $fetch['nik'], 'no' => $fetch['no']);
								$i++;
							}
							$array = array_values(array_unique($week));
							foreach($data as $section => $list){
								if($list['week'] === $array[0]){
						?>
							<tr>
								<td><?php echo $list['nik']?></td>
								<td><?php echo $list['no']?></td>
							</tr>
						<?php
								}
 
							}
 
						?>
 
					</tbody>
				</table>
			</div>
			<div id="week2" class="tab-pane fade">
				<table class="table table-bordered">
					<thead class="alert-success">
						<tr>
							<th>Item Name</th>
							<th>Brand Name</th>
						</tr>
					</thead>
					<tbody style="background-color:#fff;">
						<?php
							$data = [];
							$week = [];
							$i = 0;
							$query = $koneksi->query( "SELECT WEEK(tgl) AS 'week', nik, no FROM stock WHERE YEAR(tgl) = '$year' && MONTH(tgl) = '$month' ORDER BY 'week' ASC") or die(mysqli_error());
							while($fetch = mysqli_fetch_assoc($query)){
								$week[$i] = $fetch['week'];
								$data[$i] = array('week' => $fetch['week'],'nik' => $fetch['nik'], 'no' => $fetch['no']);
								$i++;
							}
							$array = array_values(array_unique($week));
							foreach($data as $section => $list){
								if($list['week'] === $array[1]){
						?>
							<tr>
								<td><?php echo $list['nik']?></td>
								<td><?php echo $list['no']?></td>
							</tr>
						<?php
								}
 
							}
 
						?>
 
					</tbody>
				</table>
			</div>
			<div id="week3" class="tab-pane fade">
				<table class="table table-bordered">
					<thead class="alert-success">
						<tr>
							<th>Item Name</th>
							<th>Brand Name</th>
						</tr>
					</thead>
					<tbody style="background-color:#fff;">
						<?php
							$data = [];
							$week = [];
							$i = 0;
							$query = $koneksi->query( "SELECT WEEK(tgl) AS 'week', nik, no FROM antrian WHERE YEAR(tgl) = '$year' && MONTH(tgl) = '$month' ORDER BY 'week' ASC") or die(mysqli_error());
							while($fetch = mysqli_fetch_assoc($query)){
								$week[$i] = $fetch['week'];
								$data[$i] = array('week' => $fetch['week'],'nik' => $fetch['nik'], 'no' => $fetch['no']);
								$i++;
							}
							$array = array_values(array_unique($week));
							foreach($data as $section => $list){
								if($list['week'] === $array[2]){
						?>
							<tr>
								<td><?php echo $list['nik']?></td>
								<td><?php echo $list['no']?></td>
							</tr>
						<?php
								}
 
							}
 
						?>
 
					</tbody>
				</table>
			</div>
			<div id="week4" class="tab-pane fade">
				<table class="table table-bordered">
					<thead class="alert-success">
						<tr>
							<th>Item Name</th>
							<th>Brand Name</th>
						</tr>
					</thead>
					<tbody style="background-color:#fff;">
						<?php
							$data = [];
							$week = [];
							$i = 0;
							$query = $koneksi->query( "SELECT WEEK(tgl) AS 'week', nik, no FROM antrian WHERE YEAR(tgl) = '$year' && MONTH(tgl) = '$month' ORDER BY 'week' ASC") or die(mysqli_error());
							while($fetch = mysqli_fetch_assoc($query)){
								$week[$i] = $fetch['week'];
								$data[$i] = array('week' => $fetch['week'],'nik' => $fetch['nik'], 'no' => $fetch['no']);
								$i++;
							}
							$array = array_values(array_unique($week));
							foreach($data as $section => $list){
								if($list['week'] === $array[3]){
						?>
							<tr>
								<td><?php echo $list['nik']?></td>
								<td><?php echo $list['no']?></td>
							</tr>
						<?php
								}
 
							}
 
						?>
 
					</tbody>
				</table>
			</div>
		</div>
 
 
<?php
	}else{
?>
	<table class="table table-bordered">
			<thead class="alert-success">
				<tr>
					<th>Item Name</th>
					<th>Brand Name</th>
					<th>tgl</th>
				</tr>
			</thead>
			<tbody style="background-color:#fff;">
				<?php
					
 
					$query = $koneksi->query( "SELECT * FROM antrian ORDER BY tgl ASC") or die(mysqli_error());
					while($fetch = mysqli_fetch_array($query)){
				?>
				<tr>
					<td><?php echo $fetch['nik']?></td>
					<td><?php echo $fetch['no']?></td>
					<td><?php echo $fetch['tgl']?></td>
				</tr>
				<?php
					}
				?>
			</tbody>
		</table>
<?php
	}
?>
