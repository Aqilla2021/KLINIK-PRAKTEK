-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2023 at 06:57 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `klinik`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `foto` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama`, `username`, `password`, `foto`) VALUES
(3, 'admin', 'admin', 'admin', 'banner4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `antrian`
--

CREATE TABLE `antrian` (
  `id_antrian` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `jam` time NOT NULL,
  `no` varchar(225) NOT NULL,
  `nik` varchar(225) NOT NULL,
  `status` varchar(30) NOT NULL,
  `ket` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `antrian`
--

INSERT INTO `antrian` (`id_antrian`, `tgl`, `jam`, `no`, `nik`, `status`, `ket`) VALUES
(9, '2023-08-20', '09:39:14', '1', '123', 'Datang', 'Lanjut Rekam Medik'),
(10, '2023-08-20', '09:40:21', '2', '321', 'Datang', 'Selesai Rekam Medik'),
(11, '2023-08-24', '09:49:17', '1', '123', 'Aktif', ''),
(12, '2023-08-16', '09:49:49', '1', '1234', 'Aktif', ''),
(13, '2023-08-21', '11:18:07', '1', '321', 'Aktif', '');

-- --------------------------------------------------------

--
-- Table structure for table `informasi`
--

CREATE TABLE `informasi` (
  `idinfo` int(255) NOT NULL,
  `informasi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `informasi`
--

INSERT INTO `informasi` (`idinfo`, `informasi`) VALUES
(4, 'Puskesmas (Pusat Kesehatan Masyarakat) adalah suatu organisasi kesehatan fungsional yang merupakan pusat pengembangan kesehatan masyarakat yang juga membina peran serta masyarakat di samping memberikan pelayanan secara menyeluruh dan terpadu kepada masyarakat di wilayah kerjanya dalam bentuk kegiatan pokok.');

-- --------------------------------------------------------

--
-- Table structure for table `kontak`
--

CREATE TABLE `kontak` (
  `id_kontak` int(11) NOT NULL,
  `judul` varchar(225) NOT NULL,
  `tlp` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `maps` varchar(225) NOT NULL,
  `alamat` varchar(225) NOT NULL,
  `logo` varchar(225) NOT NULL,
  `tentangkami` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kontak`
--

INSERT INTO `kontak` (`id_kontak`, `judul`, `tlp`, `email`, `maps`, `alamat`, `logo`, `tentangkami`) VALUES
(1, 'KLINIK PRAKTEK', '054-007', 'KLINIKPRAKTEK@GMAIL.COM', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d48306.05339877067!2d-74.245183970742!3d40.825144655510556!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2555646a723a1%3A0x449f3366d017b214!2sMontclair%2C+NJ%2C+US', 'JAKARTA', 'inbox.png', 'tentang kami sistem informasi pelayanan dokter praktek');

-- --------------------------------------------------------

--
-- Table structure for table `obat`
--

CREATE TABLE `obat` (
  `id_obat` int(11) NOT NULL,
  `nama_obat` varchar(225) NOT NULL,
  `jenis` varchar(225) NOT NULL,
  `stok` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `obat`
--

INSERT INTO `obat` (`id_obat`, `nama_obat`, `jenis`, `stok`) VALUES
(1, 'Paracetamol', 'Tablet', '13'),
(2, 'Amoxilin', 'Tablet', '25'),
(3, 'curcuma plus', 'Sirup', '27');

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE `pasien` (
  `id_pasien` int(11) NOT NULL,
  `nik` varchar(225) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `alamat` varchar(225) NOT NULL,
  `no_hp` varchar(225) NOT NULL,
  `norekammedik` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`id_pasien`, `nik`, `nama`, `alamat`, `no_hp`, `norekammedik`) VALUES
(9, '123', 'mus', 'JLAN KYAI TAPAH', '082151355959', 'HB0001'),
(10, '321', 'dolah', 'JLAN KYAI TAPAH', '0121', 'HB0002'),
(11, '1234', 'aa', 'dfsdfdsfdff', '424234', 'HB0003'),
(12, '6112132323', '', '', '', 'HB0004');

-- --------------------------------------------------------

--
-- Table structure for table `rekammedik`
--

CREATE TABLE `rekammedik` (
  `id_rekammedik` int(11) NOT NULL,
  `norekammedik` varchar(22) NOT NULL,
  `nik` varchar(225) NOT NULL,
  `diagnosa` varchar(225) NOT NULL,
  `tgl` date NOT NULL,
  `jam` time NOT NULL,
  `keluhan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rekammedik`
--

INSERT INTO `rekammedik` (`id_rekammedik`, `norekammedik`, `nik`, `diagnosa`, `tgl`, `jam`, `keluhan`) VALUES
(19, 'HB0002', '321', 'alergia', '2023-08-20', '11:24:04', 'gatal');

-- --------------------------------------------------------

--
-- Table structure for table `resepobat`
--

CREATE TABLE `resepobat` (
  `id_resep` int(11) NOT NULL,
  `id_rekammedik` varchar(225) NOT NULL,
  `id_obat` varchar(225) NOT NULL,
  `jumlah` varchar(11) NOT NULL,
  `dosis` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resepobat`
--

INSERT INTO `resepobat` (`id_resep`, `id_rekammedik`, `id_obat`, `jumlah`, `dosis`) VALUES
(613, '19', '2', '1', '5mg');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id_slider` int(11) NOT NULL,
  `judul` varchar(225) NOT NULL,
  `foto` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id_slider`, `judul`, `foto`) VALUES
(1, 'WELCOM', 'bnr3.jpg'),
(2, 'WELCOM', 'bnr.jpg'),
(4, 'WELCOM', 'b5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `stokobat`
--

CREATE TABLE `stokobat` (
  `id_stok` int(11) NOT NULL,
  `id_obat` varchar(225) NOT NULL,
  `jml_stok` varchar(225) NOT NULL,
  `suplayer` varchar(225) NOT NULL,
  `tgl` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stokobat`
--

INSERT INTO `stokobat` (`id_stok`, `id_obat`, `jml_stok`, `suplayer`, `tgl`) VALUES
(2, '2', '30', 'kimia farma', '2023-07-16'),
(4, '3', '30', 'kimia farma', '2023-07-16'),
(5, '1', '30', 'kimia farma', '2023-07-16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `antrian`
--
ALTER TABLE `antrian`
  ADD PRIMARY KEY (`id_antrian`);

--
-- Indexes for table `informasi`
--
ALTER TABLE `informasi`
  ADD PRIMARY KEY (`idinfo`);

--
-- Indexes for table `kontak`
--
ALTER TABLE `kontak`
  ADD PRIMARY KEY (`id_kontak`);

--
-- Indexes for table `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id_pasien`);

--
-- Indexes for table `rekammedik`
--
ALTER TABLE `rekammedik`
  ADD PRIMARY KEY (`id_rekammedik`);

--
-- Indexes for table `resepobat`
--
ALTER TABLE `resepobat`
  ADD PRIMARY KEY (`id_resep`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id_slider`);

--
-- Indexes for table `stokobat`
--
ALTER TABLE `stokobat`
  ADD PRIMARY KEY (`id_stok`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `antrian`
--
ALTER TABLE `antrian`
  MODIFY `id_antrian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `informasi`
--
ALTER TABLE `informasi`
  MODIFY `idinfo` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `kontak`
--
ALTER TABLE `kontak`
  MODIFY `id_kontak` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `obat`
--
ALTER TABLE `obat`
  MODIFY `id_obat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id_pasien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `rekammedik`
--
ALTER TABLE `rekammedik`
  MODIFY `id_rekammedik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `resepobat`
--
ALTER TABLE `resepobat`
  MODIFY `id_resep` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=614;
--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id_slider` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `stokobat`
--
ALTER TABLE `stokobat`
  MODIFY `id_stok` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
