<?php
$koneksi = new mysqli ("localhost","root","","praktekdokter");
?>

<!-- end -->