<div class="slider">
			<div class="callbacks_container">
				<ul class="rslides callbacks callbacks1" id="slider4">
					<?php 
      $resultsd = $koneksi->query( "SELECT * FROM slider order by id_slider asc");
      $no =0;
      while ($slider = mysqli_fetch_assoc($resultsd)) {

        ?>
					<li>
						<div class="banner-top<?php if($no=0){}else{ echo $no;}?>" style="background: url(images/slider/<?= $slider['foto'];?>) no-repeat 0px 0px;
	background-size: cover;
	-webkit-background-size: cover;
	-moz-background-size: cover;
	-o-background-size: cover;
	-moz-background-size: cover;
	min-height: 780px;">
						<div class="layer">
							<div class="container">
								<div class="banner-info_agile_w3ls">
									<h2><?= $slider['judul'];?></h2>
									
								</div>
							</div>
						</div>
						</div>
					</li>
<?php $no++;
}?>

				
				</ul>
			</div>
			<div class="clearfix"> </div>

			
		