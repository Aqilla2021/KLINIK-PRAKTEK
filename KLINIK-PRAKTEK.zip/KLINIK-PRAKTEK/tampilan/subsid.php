<?php 
      $resultsd = $koneksi->query( "SELECT * FROM slider order by id_slider asc limit 1");
      $no =0;
      while ($slider = mysqli_fetch_assoc($resultsd)) {

        ?>

<div class="innerpage-banner" style="background: url(images/slider/<?= $slider['foto'];?>) no-repeat center;
    background-size: cover;
    min-height: 300px;">
	<div class="layer1">
	</div>
</div>	<?php }?>