<header>
	<div class="container agile-banner_nav">
		<div class="row header-top">
			<div class="col-md-5 top-left p-0">
				<p><i class="fa fa-phone" aria-hidden="true"></i> Telp : 054-007 </p>
			</div>
			<div class="col-md-7 top-right p-0">
				<p><i class="fa fa-map-marker" aria-hidden="true"></i>JAKARTA
			</div>
		</div>
	
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			
			<h1><a class="navbar-brand" href="?page=page/home">KLINIK PRAKTEK</a></h1>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item active">
						<a class="nav-link" href="?page=page/home">Home <span class="sr-only">(current)</span></a>
					</li>
					
					<li class="nav-item">
						<a class="nav-link" href="?page=page/antrianhariini">Antrian Hari Ini</a>
					</li>
					
					
					
					<li class="nav-item pr-lg-0">
						<a class="nav-link pr-lg-0" href="?page=page/kontak">Kontak Kami</a>
					</li>
				</ul>
			</div>
		  
		</nav>
	</div>
</header>