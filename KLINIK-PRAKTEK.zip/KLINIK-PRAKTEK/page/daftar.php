<?php include"tampilan/subsid.php";

 $kode = $koneksi->query( "SELECT norekammedik from pasien order by norekammedik desc");
  $data = mysqli_fetch_assoc($kode);
  $num = substr($data['norekammedik'], 2, 4);
  $add = (int) $num + 1;
  if(strlen($add) == 1){
    $format = "HB000".$add;
  }else if(strlen($add) == 2){
    $format = "HB00".$add;
  }
  else if(strlen($add) == 3){
    $format = "HB0".$add;
  }else{
    $format = "HB".$add;
  }
  ?>

		
		

<!-- booking form -->
<section class="booking py-5" id="booking">
	<?php
//default time zone
date_default_timezone_set("Asia/Jakarta");
//fungsi check tanggal merah
function tanggalMerah($value) {
	$array = json_decode(file_get_contents("https://raw.githubusercontent.com/guangrei/APIHariLibur_V2/main/calendar.json"),true);

	//check tanggal merah berdasarkan libur nasional
	if(isset($array[$value]) && $array[$value]["holiday"])
:		echo"tanggal merah\n";
         print_r($array[$value]);

	//check tanggal merah berdasarkan hari minggu
	elseif(
date("D",strtotime($value))==="Sun")
:		echo"tanggal merah hari minggu";

	//bukan tanggal merah
	else
		:echo"bukan tanggal merah";
	endif;
}

//testing
$hari_ini = date("Y-m-d");

?>
	<h3 class="text-center mb-4">Daftar No Antrian</h3>
	<p class="text-center mb-4"> Note ** silahkan inputkan Tanggal dan NIK saja jika sudah pernah melakukan kunjungan Berobat</p>
	<div class="container">
		<div class="book-form">
		   <form action="#" method="post">
			<div class="row">
				<div class="col-md-3 col-sm-6 col-6 px-2 form-time-w3layouts editContent">
						<label class="editContent"><span class="fa fa-card" aria-hidden="true"></span>NIK</label>
						<input type="text" name="nik"required="">
						<input type="hidden" name="norekammedik" value="<?= $format?>">
				</div>
				<div class="col-md-3 col-sm-6 col-6 px-2 form-time-w3layouts editContent">
						<label class="editContent"><span class="fa fa-user" aria-hidden="true"></span>Nama</label>
						<input type="text" name="nama" >
				</div>
				<div class="col-md-3 col-sm-6 col-6 px-2 form-time-w3layouts editContent">
						<label class="editContent"><span class="fa fa-map-marker" aria-hidden="true"></span>Alamat</label>
						<input type="text" name="alamat" >
				</div>

				<div class="col-md-3 col-sm-6 col-6 px-2 form-time-w3layouts editContent">
						<label class="editContent"><span class="fa fa-phone" aria-hidden="true"></span>No Hp</label>
						<input type="text" name="no_hp" >
				</div>
				
				<div class="col-md-3 col-sm-6 col-6 px-2 form-time-w3layouts editContent">
						<label class="editContent"><span class="fa fa-table" aria-hidden="true"></span>Tanggal</label>
						<input type="date" name="tgl"required="">
				</div>
				
				<div class="col-md-2 px-2 col-sm-4 col-6 form-left-agileits-submit editContent">
					  <input type="submit" name="daftar" value="Daftar">
				</div>
				</div>
			</form>
		</div>
	</div>
</section>
<!-- //booking form -->


<?php if (isset($_POST['daftar'])) {


   $alamat=addslashes($_POST['alamat']);
   $nama=addslashes($_POST['nama']);
   $nik=addslashes($_POST['nik']);
   $no_hp=addslashes($_POST['no_hp']);
   $tgl=addslashes($_POST['tgl']);
   
   if(
date("D",strtotime($tgl))==="Sun"){
   	 echo"<script>alert('anda gagal mendaftar dikarenkan tanggal yang anda pilih merupakan hari libur, silahkan pilih tanggal lain!!!'); window.location = '?page=page/daftar'</script>";
   	}else{
   $norekammedik=addslashes($_POST['norekammedik']);
   $result = $koneksi->query( "SELECT * FROM antrian  where tgl='$tgl' and status='Aktif' order by no desc");
      $cob=mysqli_fetch_array($result);

      $antr=$cob['no'];
      $tl=$cob['no'];
      $p=mysqli_num_rows($koneksi->query("select * from antrian where tgl='$tgl' and status='Aktif' "));

             if($p == 0){ $antr='1';}else{ $antr=$tl+1;}
if($antr == 10){
  echo"<script>alert('Pendaftaran sudah penuh silahkan pilih tanggal lain!!!'); window.location = '?page=page/daftar'</script>";
}else{
   $pa=mysqli_num_rows($koneksi->query("select * from antrian where tgl='$tgl' and nik='$nik' "));
if($pa==1){echo"<script>alert('ANDA SUDAH MENGAMBIL ANTRIAN PADA TANGGAL $tgl !!!'); window.location = '?page=page/daftar'</script>";}else{
  $pas=mysqli_num_rows($koneksi->query("select * from pasien where nik='$nik'  "));
  if($pas ==1){}else{
    $query_simpan =$koneksi->query( "INSERT INTO pasien SET 
        nama='$nama',
        nik='$nik',
        norekammedik='$norekammedik',
        alamat='$alamat',
        no_hp='$no_hp'
        ");
  }
        $query_simpan =$koneksi->query( "INSERT INTO antrian SET 
        no='$antr',
        nik='$nik',
        jam='$jam_sekarang',
        status='Aktif',
        tgl='$tgl'
        ");

echo"<script>alert('ANDA BERHASIL MENDAFTAR!!!'); window.location = '?page=page/daftar'</script>";
 }
}
}
}
?>