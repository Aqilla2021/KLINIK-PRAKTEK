<?php include"tampilan/slider.php";?>

		
			
		<!-- To bottom button-->
		<div class="thim-click-to-bottom">
			<div class="rotate">
				<a href="#booking" class="scroll">
					<i class="fa fa-ellipsis-v"></i>
				</a>
			</div>
		</div>
		<!-- //To bottom button-->
		</div>
		<!--//Slider-->
		

<!-- booking form -->
<section class="booking py-5" id="booking">
	<h3 class="text-center mb-4">Daftar  Antrian</h3>
	<div class="container">
		<div class="book-form">
		   <form action="#" method="post">
			<div class="row">
				
				<div class="col-md-3 col-sm-6 col-6 px-2 form-time-w3layouts editContent">
						<label class="editContent"><span class="fa fa-user" aria-hidden="true"></span>Nama</label>
						<input type="text" name="nama" >
				</div>
				<div class="col-md-3 col-sm-6 col-6 px-2 form-time-w3layouts editContent">
						<label class="editContent"><span class="fa fa-map-marker" aria-hidden="true"></span>Alamat</label>
						<input type="text" name="alamat" >
				</div>

				<div class="col-md-3 col-sm-6 col-6 px-2 form-time-w3layouts editContent">
						<label class="editContent"><span class="fa fa-phone" aria-hidden="true"></span>No Hp</label>
						<input type="text" name="no_hp" >
				</div>
				
				<div class="col-md-3 col-sm-6 col-6 px-2 form-time-w3layouts editContent">
						<label class="editContent"><span class="fa fa-table" aria-hidden="true"></span>Tanggal</label>
						<input type="date" name="tgl"required="">
				</div>
				
				<div class="col-md-2 px-2 col-sm-4 col-6 form-left-agileits-submit editContent">
					  <input type="submit" name="daftar" value="Daftar">
				</div>
				</div>
			</form>
		</div>
	</div>
</section>
<!-- //booking form -->

<!-- booking bottom -->	
<section class="bottom py-5">
	<div class="container">
		<h3 class="heading text-center mb-sm-5 mb-3">Antrian Hari Ini </h3>
			<div class="row offer-grids pt-5">
				 <?php 
      

      $resulta = $koneksi->query( "SELECT * FROM antrian  where tgl='$tgl_sekarang'  order by no asc");
     
      while ($row = mysqli_fetch_assoc($resulta)) {
        $resultap = $koneksi->query( "SELECT * FROM pasien  where nik='$row[nik]'");
        $pasien = mysqli_fetch_assoc($resultap);
        ?>
				<div class="col-lg-3 col-sm-6 offer-grid">
					<img src="images/logo.jpg" alt="" class="img-fluid" />
					<center><h4 class="mt-3" style="color:white;"><?= $pasien['nama'];  ?></h4>
					<p class="mt-2" style="color:white;"><?= $pasien['alamat'];  ?></p>
					<div class="offer">
						<h3><?= $row['no']; ?> </h3>
					</div></center>
				</div>
<?php }?>
				
			</div>
	</div>
</section>
<?php if (isset($_POST['daftar'])) {


   $alamat=addslashes($_POST['alamat']);
   $nama=addslashes($_POST['nama']);
   $nik=addslashes($_POST['nik']);
   $no_hp=addslashes($_POST['no_hp']);
   $tgl=addslashes($_POST['tgl']);
   $result = $koneksi->query( "SELECT * FROM antrian  where tgl='$tgl' and status='Aktif' order by no desc");
      $cob=mysqli_fetch_array($result);

      $antr=$cob['no'];
      $tl=$cob['no'];
      $p=mysqli_num_rows($koneksi->query("select * from antrian where tgl='$tgl' and status='Aktif' "));

             if($p == 0){ $antr='1';}else{ $antr=$tl+1;}
if($antr == 15){
  echo"<script>alert('Pendaftaran sudah penuh silahkan pilih tanggal lain!!!'); window.location = '?page=page/home'</script>";
}else{
   $pa=mysqli_num_rows($koneksi->query("select * from antrian where tgl='$tgl' and nik='$nik' "));
if($pa==1){echo"<script>alert('ANDA SUDAH MENGAMBIL ANTRIAN PADA TANGGAL $tgl !!!'); window.location = '?page=page/home'</script>";}else{
  $pas=mysqli_num_rows($koneksi->query("select * from pasien where nik='$nik'  "));
  if($pas ==1){}else{
    $query_simpan =$koneksi->query( "INSERT INTO pasien SET 
        nama='$nama',
       
        alamat='$alamat',
        no_hp='$no_hp'
        ");
  }
        $query_simpan =$koneksi->query( "INSERT INTO antrian SET 
        no='$antr',
       
        jam='$jam_sekarang',
        status='Aktif',
        tgl='$tgl'
        ");

echo"<script>alert('ANDA BERHASIL MENDAFTAR!!!'); window.location = '?page=page/home'</script>";
 }
}
}
?>