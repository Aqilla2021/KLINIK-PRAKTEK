<?php include"tampilan/subsid.php";?>


<section class="bottom py-5">
	<div class="container">
		<h3 class="heading text-center mb-sm-5 mb-3">Antrian Hari Ini </h3>
			<div class="row offer-grids pt-5">
				 <?php 
      

      $resulta = $koneksi->query( "SELECT * FROM antrian  where tgl='$tgl_sekarang'  order by no asc");
     
      while ($row = mysqli_fetch_assoc($resulta)) {
        $resultap = $koneksi->query( "SELECT * FROM pasien  where nik='$row[nik]'");
        $pasien = mysqli_fetch_assoc($resultap);
        ?>
				<div class="col-lg-3 col-sm-6 offer-grid">
					<img src="images/logo.jpg" alt="" class="img-fluid" />
					<center><h4 class="mt-3" style="color:white;"><?= $pasien['nama'];  ?></h4>
					<p class="mt-2" style="color:white;"><?= $pasien['alamat'];  ?></p>
					<div class="offer">
						<h3><?= $row['no']; ?> </h3>
					</div></center>
				</div>
<?php }?>
				
			</div>
	</div>
</section>
