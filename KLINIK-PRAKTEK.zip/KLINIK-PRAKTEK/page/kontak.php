<?php include"tampilan/subsid.php";?>

<section class="w3ls-section contact py-5">
	<div class="container py-sm-3">
		<div class="w3ls-title">
			<h2 class="heading text-center mb-sm-5 mb-4">Kontak Kami</h2>
		</div>
		

		<div class="row contact_wthreerow agileits-w3layouts">
		
			<div class="col-lg-5 col-md-6 agileits_w3layouts_contact_gridl">
				<div class="agileits_mail_grid_right_grid">
					<h4>Info Kontak</h4>
				
					<ul class="contact_info">
						<li><span class="fa fa-map-marker" aria-hidden="true"></span>JAKARTA</li>
						<li><span class="fa fa-envelope" aria-hidden="true"></span><a href="">KLINIKPRAKTEK@GMAIL.COM</a></li>
						<li><span class="fa fa-phone" aria-hidden="true"></span>054-007</li>
						<li><span class="fa fa-globe" aria-hidden="true"></span><a href="#">KLINIK PRAKTEK</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-7 col-md-6 mt-md-0 mt-5 w3l_contact_form">
				<h4>Maps</h4>
					<div class="w3ls_map">
			<iframe src="<?= $kontak['maps'];?>"></iframe>
		</div>

			</div>
		</div>
	</div>
</section>